"use strict"

const cardText = document.getElementById("cardText");
