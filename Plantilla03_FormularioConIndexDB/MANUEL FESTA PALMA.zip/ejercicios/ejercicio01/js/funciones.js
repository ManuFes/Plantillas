"use strict";


function mostrarSolucion() {
    console.log("Estoy mostrando la solución del ejercicio.");
    cardText.innerHTML = "<p>Estoy mostrando la solución del ejercicio</p>";
}

